
function TermsAndConditions() {
  return (
    <div>
      <h1>Terms and Conditions</h1>
      <p>Welcome to Stem lab! Please read these terms and conditions carefully before using our services.</p>

      <h2>1. Introduction</h2>
      <p>These Terms and Conditions govern your use of our website and services. By accessing or using our services, you agree to be bound by these terms. If you do not agree to these terms, you may not use our services.</p>

      <h2>2. Use of the Website</h2>
      <p>You agree to use the website for lawful purposes only. You must not use the website in a way that violates any applicable local, national, or international law or regulation.</p>

      <h2>3. User Accounts</h2>
      <p>If you create an account on our website, you are responsible for maintaining the confidentiality of your account information, including your password. You agree to notify us immediately of any unauthorized use of your account.</p>

      <h2>4. Intellectual Property</h2>
      <p>The content on our website, including text, graphics, logos, and images, is protected by intellectual property laws. You may not reproduce, distribute, or create derivative works of our content without our express written permission.</p>

      <h2>5. Limitation of Liability</h2>
      <p>We are not liable for any damages arising from your use of our website or services. This includes, but is not limited to, direct, indirect, incidental, or consequential damages.</p>

      <h2>6. Changes to Terms and Conditions</h2>
      <p>We reserve the right to update or modify these terms and conditions at any time without prior notice. Your continued use of our website after any changes indicates your acceptance of the new terms.</p>

      <h2>7. Contact Information</h2>
      <p>If you have any questions about these terms and conditions, please contact us at support@stem.com.</p>

      <h2>8. Governing Law</h2>
      <p>These terms and conditions are governed by and construed in accordance with the laws of India.</p>
    </div>
  );
}

export default TermsAndConditions;
