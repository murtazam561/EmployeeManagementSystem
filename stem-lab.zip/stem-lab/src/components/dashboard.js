function Dashboard({ userName }) {
  const userDetails = {
    salary: "$70,000",
    department: "Engineering",
    manager: "Elon Musk",
  };

  return (
    <div>
      <main>
        <h1>Welcome, {userName}!</h1>
        <section>
          <h2>User Details</h2>
          <p><strong>Salary:</strong> {userDetails.salary}</p>
          <p><strong>Department:</strong> {userDetails.department}</p>
          <p><strong>Manager:</strong> {userDetails.manager}</p>
        </section>
        <section>
          <h2>About Work to Do</h2>
          <p>Your work will show up here when available.</p>
        </section>
      </main>
    </div>
  );
}

export default Dashboard;
