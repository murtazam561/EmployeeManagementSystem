function Home() {
return(
<div>
<main>
<h1>Explore the world of enovation with us. </h1>
<p>
join us on our exciting journey to inovate, research, and explore new ways that are still to be found.
</p>
  <h2>Welcome to STEM-Lab</h2>
  <h3>Our Mission</h3>
  <p>
    At STEM-Lab, we are dedicated to driving innovation in the fields of Science, Technology, Engineering, and Mathematics. Our mission is to empower organizations with cutting-edge employee management solutions that streamline operations, foster collaboration, and maximize productivity.
  </p>

  <h3>Our Vision</h3>
  <p>
    We envision a future where technology seamlessly integrates with human resources to create workplaces that are efficient, inclusive, and forward-thinking. STEM-Lab is committed to being at the forefront of this transformation, providing tools that adapt to the ever-evolving needs of businesses.
  </p>

  <h3>What We Offer</h3>
  <ul>
    <li>
      <strong>Employee Management</strong>: Our platform offers comprehensive tools to manage employee details, track performance, and streamline administrative tasks.
    </li>
    <li>
      <strong>Department Management</strong>: Easily assign employees to departments, manage teams, and ensure smooth departmental operations.
    </li>
    <li>
      <strong>Custom Solutions</strong>: We understand that every organization is unique. STEM-Lab provides customizable solutions that fit the specific needs of your business.
    </li>
    <li>
      <strong>Secure Access</strong>: With robust security features, we ensure that only authorized personnel have access to sensitive information, keeping your data safe.
    </li>
  </ul>

  <h3>Why Choose STEM-Lab?</h3>
  <ul>
    <li>
      <strong>Innovation</strong>: We leverage the latest technologies to provide you with the most advanced employee management tools.
    </li>
    <li>
      <strong>Reliability</strong>: Our platform is designed to be dependable, ensuring that your operations run smoothly without interruption.
    </li>
    <li>
      <strong>User-Friendly Interface</strong>: STEM-Lab’s intuitive design ensures that both employees and administrators can easily navigate the system.
    </li>
  </ul>

  <h3>Join Us in Shaping the Future</h3>
  <p>
    At STEM-Lab, we are not just building tools; we are building the future of work. Join us in creating a workplace where technology and human potential combine to achieve extraordinary results.
  </p>
</main>
</div>
);
}
export default Home;