
function PrivacyPolicy() {
  return (
    <div>
      <main>
        <h1>Privacy Policy</h1>
        <p>
          At STEM-Lab, your privacy is important to us. This Privacy Policy outlines how we collect, use, disclose, and safeguard your information when you use our services. By accessing or using our services, you agree to the terms of this Privacy Policy.
        </p>

        <h2>Information We Collect</h2>
        <p>
          We may collect personal information from you when you visit our site, register, log in, make a purchase, or fill out a form. The information collected may include your name, email address, phone number, payment information, and other relevant details.
        </p>

        <h2>How We Use Your Information</h2>
        <p>
          The information we collect is used to enhance your experience, improve our website, process transactions, and provide customer service. We do not sell, trade, or otherwise transfer your personal information to third parties without your consent.
        </p>

        <h2>Data Security</h2>
        <p>
          We implement various security measures to maintain the safety of your personal information. However, no method of transmission over the internet or method of electronic storage is 100% secure, and we cannot guarantee absolute security.
        </p>

        <h2>Cookies and Tracking Technologies</h2>
        <p>
          Our site may use cookies and similar technologies to enhance your experience, analyze usage patterns, and improve our services. You can choose to disable cookies through your browser settings, but this may affect your ability to use certain features of our site.
        </p>
        <h2>Your Consent</h2>
        <p>
          By using our site, you consent to our Privacy Policy. If we decide to change our Privacy Policy, we will post those changes on this page.
        </p>

        <h2>Contact Us</h2>
        <p>
          If you have any questions or concerns about our Privacy Policy, please contact us at support@stemlab.com.
        </p>
      </main>
    </div>
  );
}

export default PrivacyPolicy;
