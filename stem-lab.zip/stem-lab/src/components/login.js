import {Link} from 'react-router-dom';
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';

function Login({ onLogin }) {
  const [userName, setUserName] = useState("");
  const [email, setEmail] = useState("");
const [userPassword, setUserPassword] = useState("");
const [showPassword, setShowPassword] = useState(false);
  const navigate = useNavigate();


  const handleSubmit = (e) => {
    e.preventDefault();
    if (userName && email && userPassword) {
      onLogin(userName); 
      navigate('/'); 
    } else {
      alert('enter your values carefully.');
    }
  };

  return (
    <div>
      <h2>Login Page</h2>
      <form onSubmit={handleSubmit}>
        <div>
          <label htmlFor="user_name">Please enter your user name:</label>
          <input
            type="text"
id="user_name"
            value={userName}
            onChange={(e) => setUserName(e.target.value)}
            required
autofocus
          />
        </div>
        <div>
          <label htmlFor="email"> Please enter your Email: </label>
          <input
            type="email"
id="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </div>
<br />
<label htmlFor="user_password"> Please enter your password: </label>
<input type={showPassword ? "text" : "password"} id="user_password" value={userPassword} onChange={(e) => setUserPassword(e.target.value)} required />
<br />
<button type="button" onClick={() => setShowPassword(!showPassword)}>{showPassword ? "Hide Password" : "Show Password"}  </button>

<br />
<p>
before Logging in you may want to review our, {<Link to="/privacypolicy"> Privacy Policy </Link>}
<br />
and
<br />
{<Link to="/termsconditions"> Terms and Conditions </Link>}
</p>
        <button type="submit">Login</button>
      </form>
<p>
if your an Admin:
</p>
<Link to="/adminlogin"> Login as Admin </Link>
    </div>
  );
}

export default Login;
