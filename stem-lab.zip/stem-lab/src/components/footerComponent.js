import {Link} from 'react-router-dom';
function Footer() {
return(
<div>
<footer>
<Link to = "/termsAndConditions">terms and conditions</Link>
<Link to = "/privacyPolicy">PrivacyPolicy </Link>
<Link to ="/contact">contact us</Link>
<br />
&copy; 2024 by Stem Lab,
</footer>
</div>
);
}
export default Footer;