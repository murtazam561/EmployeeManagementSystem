import AdminLogin from './adminLogin';
function AdminDashboard({adminUser}) {
return(
<div>
<h1>welcome to your DashBoard {adminUser} </h1>
<p>
through admin controls you can view, manage, and add new employees, departments, and perform crutial operations to manage the company..
</p>
<h2>Manage Employees: </h2>
<button type="button"> View employees list </button>
<br />
<button type="button">Manage Employees </button>
<br />
<button type="button">Add new Employees </button>
<br />
<button type="button"> Remove Employee </button>
<br />
<button type="button"> Assign Manager to the Employee </button>
<br />
<h2>Leadership Management: </h2>
<button type="button">View Manager's </button>
<br />
<button type="button"> Add New Manager</button>
<br />
<button type="button">Remove Manager </button>
<h2> Manage departments </h2>
<button type="button"> View current departments</button>
<br />
<button type="button"> Manage Departments </button>
<br />
<button type="button">Add new department </button>
<br />
<button type="button">View Department Reports </button>
<br />
<button type="button">Remove Department </button>



</div>
);
}
export default AdminDashboard;