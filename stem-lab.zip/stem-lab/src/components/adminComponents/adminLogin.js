import {useState} from 'react';
import {useNavigate} from 'react-router-dom';
function AdminLogin({onAdminLogin}) {
const [adminUser, setAdminUser] = useState("");
const [adminEmail, setAdminEmail] = useState("");
const [adminPassword, setAdminPassword] = useState("");

const navigate= useNavigate();
const handleAdminLogin= (e) => {
e.preventDefault();
if (adminUser=="admin" && adminEmail=="admin@company.com" && adminPassword=="password") {
onAdminLogin(adminUser);
navigate('/');
}
else{
alert("Unauthorized admin login credentials");
}
}
return(
<div>
<h2> Admin Login form </h2>
<p>
please feel in the both fields carefuly!
</p>
<form onSubmit={handleAdminLogin}>
<label htmlFor="user_name">Please enter your Admin User name: </label>
<input type="text" id="user_name" value={adminUser} onChange={(e) => setAdminUser(e.target.value)} require />
<label htmlFor="email_admin">please provide your admin Email ID: </label>
<input type="email" id="email_admin" value={adminEmail} onChange={(e) => setAdminEmail(e.target.value)} required />
<br />
<label htmlFor="admin_password"> Please enter your Password: </label>
<input type="password" id="admin_password" value={adminPassword} onChange={(e) => setAdminPassword(e.target.value)} required />
<button type="submit"> Login as Admin  </button>
</form>


</div>
);
}
export default AdminLogin;