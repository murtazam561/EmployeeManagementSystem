import { BrowserRouter as Router, Route, Routes, Link } from 'react-router-dom';
import { useState } from 'react';
import Home from './components/home';
import Dashboard from './components/dashboard';
import AdminDashboard from './components/adminComponents/adminDashboard';
import Login from './components/login';
import AdminLogin from './components/adminComponents/adminLogin';
import Footer from './components/footerComponent';
import PrivacyPolicy from './components/privacyPolicy';
import TermsAndConditions from './components/termsAndConditions'; 
import Contact from './components/contact';
import logo from './components/Logo.png';
function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [isAdminLoggedIn, setIsAdminLoggedIn] = useState(false);
  const [userName, setUser] = useState("");
  const [adminUser, setAdminUser] = useState("");

  const handleLogin = (username) => {
  setIsLoggedIn(true);
  setIsAdminLoggedIn(false); 
  setUser(username);
  };

  const handleAdminLogin = (adminusername) => {
  setIsAdminLoggedIn(true);
  setIsLoggedIn(false); 
  setAdminUser(adminusername);
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    setIsAdminLoggedIn(false);
    setUser("");
    setAdminUser("");
  };

  return (
    <div>
  <Router>
  <header>
  <img src={logo} alt='Logo-stem lab' />
  <nav>
  {isLoggedIn || isAdminLoggedIn ? <button onClick={handleLogout}>Logout</button> : null}
  <ul>
  <li><Link to="/">Home</Link></li>
  {!isLoggedIn && !isAdminLoggedIn && <li><Link to="/login">Login</Link></li>}
  {!isLoggedIn && !isAdminLoggedIn && <li><Link to="/adminlogin">Admin Login</Link></li>}
  {isLoggedIn && <li><Link to="/dashboard">Dashboard</Link></li>}
  {isAdminLoggedIn && <li><Link to="/admindashboard">Admin Dashboard</Link></li>}
  </ul>
  </nav>
  </header>
  <Routes>
  <Route path="/" element={<Home />} />
  <Route path="/login" element={<Login onLogin={handleLogin} />} />
  <Route path="/adminlogin" element={<AdminLogin onAdminLogin={handleAdminLogin} />} />
  <Route path="/dashboard" element={isLoggedIn ? <Dashboard userName={userName} /> : <Login onLogin={handleLogin} />} />
  <Route path="/admindashboard" element={isAdminLoggedIn ? <AdminDashboard adminUser={adminUser} /> : <AdminLogin onAdminLogin={handleAdminLogin} />} />
  <Route path="/privacyPolicy" element={<PrivacyPolicy />} />
  <Route path="/termsAndConditions" element={<TermsAndConditions />} /> 
  <Route path='/contact' element = {<Contact />} />
  </Routes>
  <Footer />
  </Router>
  

  
  </div>
  );
}

export default App;
